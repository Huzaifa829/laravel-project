<template>
  <div>REVIEW & SUBMIT</div>
</template>

<script>

export default {
  setup: () => ({
    message: "Vue is working",

  }),
};
</script>