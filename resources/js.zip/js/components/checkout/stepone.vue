<template>
  <div>hello world</div>
</template>
  
<script>
export default {
  setup: () => ({
    message: "Vue is working",
  }),
};
</script>