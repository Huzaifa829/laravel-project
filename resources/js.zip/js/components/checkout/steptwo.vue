<template>
<div>helo world 2</div>
</template>

<script>

export default {
  setup: () => ({
    message: "Vue is working",
  }),
};
</script>