<template>
  <div class="footer-main-div">
    <p class="footer_text">
      © 2000-2023 B Technic Building Office No. 204, Salah Al-Din St,Close to
      Salah Al Din Metro Station,
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
};
</script>

<style>
.footer-main-div {
  width: 100%;
  height: 80px;
  background-color: #232323;
  display: flex;
  justify-content: center;
  align-items: center;
}
.footer_text {
  text-align:center ;
  font-size: 15px;
  color: gray;
  margin: 0;
}
</style>